Files for Homework 4.

20news-18828: contains the training instances for the NB classifier
dev-set: contains 2000 development files on which accuracy can be checked during development
dev_keys.txt: file containing the true labels for all dev files
naive_bayes.py: class implementing the NB classifier. This is what you'll have to work on.
accuracy_checker.py: script to compare output with dev_keys.txt.  DO NOT TOUCH!
naive_bayes_classifier: allows to run the NB classifier trough the commandline. DO NOT TOUCH!
